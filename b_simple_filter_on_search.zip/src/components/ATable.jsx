import React, { useCallback, useEffect, useRef, useState } from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import { Button, Container } from '@mui/material';

//library
import axios from 'axios';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));


export default function ATable() {
    //state datas
    let [datas, setDatas] = useState([]); //arr of data
    const [data, setData] = useState(''); // string we filter for

    //ref
    let fieldRef = useRef(null);


    //useEffect
    useEffect(() => {
        fieldRef.current.focus();
        apiCall();
    }, []);

    let apiCall = async () => {
        let response = await axios.get('https://jsonplaceholder.typicode.com/users')
        let result = response.data;
        setDatas(result);
    }

    //handleSearch, handleReset and handleSort
    let handleSearch = async (e) => {
        e.preventDefault();
        let response = await axios.get(`https://jsonplaceholder.typicode.com/users?q=${data}`)
        let result = response.data;
        setDatas(result);
        setData('');
    }

    let handleClear = useCallback(() => {
        apiCall();
    }, [data])

    let handleSort = () => {
        let sortedUName = datas && datas.sort((prevName, nextName) => {
            if (prevName.username < nextName.username) {
                return -1;
            }
            else if (prevName.username > nextName.username) {
                return 1;
            }
        });
        setDatas(sortedUName);
    }

    console.log(datas);

    return (
        <>
            {/* input and button */}
            <Container style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }} >
                <TextField inputRef={fieldRef} onChange={(e) => setData(e.target.value)} value={data} variant="standard" label="go for a search!" color="warning" />
                <Box>
                    <Button variant='contained' color='success' size="large" onClick={handleSearch}>search</Button> &nbsp;
                    <Button variant='contained' color='error' size="large" onClick={() => handleClear()}>clear all!</Button> &nbsp;
                    <Button variant='contained' color='error' size="large" onClick={handleSort}>sort</Button>
                </Box>
            </Container>


            <br />

            {/* table */}
            <TableContainer component={Paper}>
                <Table sx={{ minWidth: 600 }} aria-label="customized table">
                    <TableHead>
                        <TableRow>
                            <StyledTableCell>UserName</StyledTableCell>
                            <StyledTableCell align="left">Name</StyledTableCell>
                            <StyledTableCell align="left">Email</StyledTableCell>
                            <StyledTableCell align="left">Street</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {
                            datas.length === 0
                                ?
                                <TableRow>
                                    <TableCell colSpan={5} align='center'>No Data found!</TableCell>
                                </TableRow>
                                :
                                datas.map(item => (
                                    <StyledTableRow key={item.id} >
                                        <StyledTableCell align="left">
                                            {item.username}
                                        </StyledTableCell>
                                        <StyledTableCell align="left">{item.name}</StyledTableCell>
                                        <StyledTableCell align="left">{item.email}</StyledTableCell>
                                        <StyledTableCell align="left">{item?.address?.street}</StyledTableCell>
                                    </StyledTableRow>
                                ))
                        }
                        {/* {datas && datas.filter((item => {
                            return data.toLocaleLowerCase() === ''
                                ? item
                                : item.username.toLocaleLowerCase().includes(data);
                        })).map((item) => (
                            <StyledTableRow key={item.id} >
                                <StyledTableCell align="center">{item.id}</StyledTableCell>
                                <StyledTableCell component="th" scope="row">
                                    {item.username}
                                </StyledTableCell>
                                <StyledTableCell align="left">{item.name}</StyledTableCell>
                                <StyledTableCell align="left">{item.email}</StyledTableCell>
                                <StyledTableCell align="left">{item?.address?.street}</StyledTableCell>
                            </StyledTableRow>
                        ))
                        }
                        {
                            datas.length === 0 ?
                                <StyledTableRow>
                                    <StyledTableCell align='center'>
                                        Data Not Found!
                                    </StyledTableCell>
                                </StyledTableRow>
                                : ''
                        } */}
                    </TableBody>
                </Table>
            </TableContainer >
        </>
    );
}