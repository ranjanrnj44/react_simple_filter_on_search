import React from 'react'
import './App.css'
//components
import ATable from './components/ATable';

function App() {

  return (
    <>
      <ATable />
    </>
  )
}

export default App
